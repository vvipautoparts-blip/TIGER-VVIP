#!/usr/bin/env bash
set -o pipefail

ROOT="/workspaces/.vvip-pr37-architect-v3"
STATE="$ROOT/state.json"
LOCK="$ROOT/state-write.os-lock"

STATUS="$(
  python3 "$ROOT/statectl.py" \
    "$STATE" \
    "$LOCK" \
    field status 2>/dev/null ||
  echo UNKNOWN
)"

STAGE="$(
  python3 "$ROOT/statectl.py" \
    "$STATE" \
    "$LOCK" \
    field stage 2>/dev/null ||
  echo UNKNOWN
)"

MESSAGE="$(
  python3 "$ROOT/statectl.py" \
    "$STATE" \
    "$LOCK" \
    field message 2>/dev/null ||
  echo UNKNOWN
)"

PID="$(
  python3 "$ROOT/statectl.py" \
    "$STATE" \
    "$LOCK" \
    field pid 2>/dev/null ||
  echo NONE
)"

case "$STATUS" in
  RUNNING)
    COLOR="\033[1;30;42m"
    LABEL="🟢 RUNNING"
    ;;
  RETRYING)
    COLOR="\033[1;30;43m"
    LABEL="🟡 RETRYING"
    ;;
  STALLED)
    COLOR="\033[1;30;43m"
    LABEL="🟠 STALLED"
    ;;
  FAILED)
    COLOR="\033[1;37;41m"
    LABEL="🔴 FAILED"
    ;;
  PASSED)
    COLOR="\033[1;30;42m"
    LABEL="✅ PASSED"
    ;;
  *)
    COLOR="\033[1;37;44m"
    LABEL="⚪ UNKNOWN"
    ;;
esac

RESET="\033[0m"

echo
echo "======================================================"
echo " VVIP TIGER — ARCHITECT-V3 GREEN BUTTON"
echo "======================================================"
printf "${COLOR} %-58s ${RESET}\n" \
  "$LABEL — PR37 ROADMAP RECONCILIATION"
echo
echo "Status : $STATUS"
echo "Stage  : $STAGE"
echo "Message: $MESSAGE"
echo "PID    : $PID"
echo
echo "Automatic merge: DISABLED"
echo "Production SQL/Supabase/Clerk: DISABLED"
echo "Tracked deletion: DISABLED"
echo "======================================================"

if [ -f "$ROOT/final-summary.txt" ]; then
  echo
  cat "$ROOT/final-summary.txt"
fi
