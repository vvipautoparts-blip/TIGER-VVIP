#!/usr/bin/env bash
set -Ee -o pipefail

ROOT="/workspaces/.vvip-pr37-architect-v3"
CHECKPOINT="/workspaces/TIGER-VVIP-AFTER-PR36"
WORKTREE="/workspaces/TIGER-VVIP-PR37-ROADMAP"

BRANCH="docs/pr37-post-pr36-roadmap-reconciliation"
REPO="vvipautoparts-blip/TIGER-VVIP"
EXPECTED_MAIN="5a4677919a79d098394d27ab671f16c301e98e1b"

STATE="$ROOT/state.json"
STATE_LOCK="$ROOT/state-write.os-lock"
RUN_LOCK="$ROOT/runner.os-lock"

RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)"
RUN_DIR="$ROOT/runs/$RUN_ID"
DRY_ROOT="$RUN_DIR/V2-TEMP-dry-run"
DETACHED=""

HEARTBEAT_PID=""
SUCCESS="false"
LAST_STAGE="starting"
FAILURE_REASON="unexpected controller stop"

mkdir -p \
  "$RUN_DIR" \
  "$ROOT/.quarantine/$RUN_ID" \
  "$ROOT/tmp"

state_write() {
  python3 "$ROOT/statectl.py" \
    "$STATE" \
    "$STATE_LOCK" \
    write \
    "$1" \
    "$2" \
    "$3" \
    "$$" \
    "$RUN_ID" \
    "$RUN_DIR"
}

state_field() {
  python3 "$ROOT/statectl.py" \
    "$STATE" \
    "$STATE_LOCK" \
    field "$1"
}

heartbeat_loop() {
  while kill -0 "$$" 2>/dev/null; do
    python3 "$ROOT/statectl.py" \
      "$STATE" \
      "$STATE_LOCK" \
      heartbeat "$$" \
      >/dev/null 2>&1 || true

    sleep 5
  done
}

cleanup() {
  local rc=$?
  trap - EXIT

  if [ -n "$HEARTBEAT_PID" ]; then
    kill "$HEARTBEAT_PID" >/dev/null 2>&1 || true
    wait "$HEARTBEAT_PID" >/dev/null 2>&1 || true
  fi

  if [ -n "$DETACHED" ]; then
    if git -C "$CHECKPOINT" worktree list --porcelain |
       grep -Fxq "worktree $DETACHED"; then
      git -C "$CHECKPOINT" worktree remove \
        --force "$DETACHED" \
        >/dev/null 2>&1 || true
    fi
  fi

  if [ "$SUCCESS" != "true" ]; then
    state_write \
      "FAILED" \
      "$LAST_STAGE" \
      "$FAILURE_REASON" \
      >/dev/null 2>&1 || true

    cat >"$ROOT/final-summary.txt" <<SUMMARY
🔴 PR37 ARCHITECT-V3 FAILED SAFELY

Reason: $FAILURE_REASON
Stage: $LAST_STAGE
Run: $RUN_DIR

Commit/Push may have occurred only if their explicit stage passed.
Automatic merge: NO
Direct main change: NO
Tracked deletion: NO
Production SQL/Supabase/Clerk: UNCHANGED
SUMMARY
  fi

  exit "$rc"
}

trap cleanup EXIT

stop() {
  FAILURE_REASON="$1"
  exit 1
}

stage() {
  LAST_STAGE="$1"

  echo
  echo "======================================================"
  echo " $2"
  echo "======================================================"

  state_write "RUNNING" "$1" "$2"
}

stage_pass() {
  echo "✅ $2"
  state_write "STAGE_PASSED" "$1" "$2"
}

network_retry() {
  local name="$1"
  local timeout_seconds="$2"
  local output="$3"
  shift 3

  local attempt
  local rc
  local delay
  local attempt_log

  for attempt in 1 2 3; do
    attempt_log="$RUN_DIR/${name}-attempt-${attempt}.log"

    state_write \
      "RUNNING" \
      "$LAST_STAGE" \
      "$name network attempt $attempt/3"

    if timeout "$timeout_seconds" "$@" \
        >"$attempt_log" 2>&1; then
      cp "$attempt_log" "$output"
      return 0
    else
      rc=$?
    fi

    if [ "$rc" -eq 124 ] ||
       grep -Eiq \
         'timeout|timed out|connection|temporary|network|reset|broken pipe|429|502|503|504|TLS|EOF' \
         "$attempt_log"; then

      state_write \
        "RETRYING" \
        "$LAST_STAGE" \
        "$name transient failure; bounded retry $attempt/3"

      delay=$((attempt * 4 + RANDOM % 5))
      sleep "$delay"
      continue
    fi

    cat "$attempt_log"
    return "$rc"
  done

  state_write \
    "STALLED" \
    "$LAST_STAGE" \
    "$name exhausted bounded network retries"

  return 1
}

validate_yaml() {
  local path="$1"

  if python3 -c 'import yaml' >/dev/null 2>&1; then
    python3 - "$path" <<'PY_YAML'
import sys
import yaml
from pathlib import Path

path = Path(sys.argv[1])
data = yaml.safe_load(path.read_text(encoding="utf-8"))

if not isinstance(data, dict):
    raise SystemExit("YAML root is not a mapping")

print("YAML_PARSE_PASS")
PY_YAML
    return
  fi

  if command -v ruby >/dev/null 2>&1; then
    ruby -e '
      require "yaml"
      data = YAML.load_file(ARGV[0])
      abort("YAML root is not a mapping") unless data.is_a?(Hash)
      puts "YAML_PARSE_PASS"
    ' "$path"
    return
  fi

  stop "No safe YAML parser is available"
}

write_review() {
  local path="$1"
  local title="$2"
  local body="$3"

  mkdir -p "$(dirname "$path")"

  cat >"$path" <<EOF
# $title

- Run ID: \`$RUN_ID\`
- Base commit: \`$EXPECTED_MAIN\`
- Protocol: \`ARCHITECT-V3\`
- Result: **PASS**

$body

## Safety statement

- Automatic merge: disabled.
- Direct main changes: none.
- Tracked deletion: none.
- Production SQL/Supabase/Clerk: unchanged.
EOF
}

# ------------------------------------------------------------
# Atomic single-instance lock
# ------------------------------------------------------------

exec 9>"$RUN_LOCK"
flock -n 9 ||
  stop "Another ARCHITECT-V3 controller owns the OS lock"

state_write \
  "RUNNING" \
  "starting" \
  "PR37 ARCHITECT-V3 controller started"

heartbeat_loop &
HEARTBEAT_PID="$!"

echo "======================================================"
echo " VVIP TIGER — ARCHITECT-V3 ZERO-TOUCH EXECUTION"
echo " الأمانة • الإتقان في الخفاء • الشفافية"
echo "======================================================"

# ------------------------------------------------------------
# Stage 1 — immutable preflight
# ------------------------------------------------------------

stage "preflight" "1/9 — IMMUTABLE BASE AND GOVERNANCE PREFLIGHT"

for tool in \
  git \
  gh \
  python3 \
  node \
  bash \
  flock \
  timeout \
  sha256sum
do
  command -v "$tool" >/dev/null 2>&1 ||
    stop "Required command unavailable: $tool"
done

gh auth status >/dev/null 2>&1 ||
  stop "GitHub CLI is not authenticated"

[ -d "$CHECKPOINT" ] ||
  stop "AFTER-PR36 checkpoint is missing"

git -C "$CHECKPOINT" rev-parse --is-inside-work-tree \
  >/dev/null 2>&1 ||
  stop "AFTER-PR36 path is not a Git worktree"

[ "$(git -C "$CHECKPOINT" rev-parse HEAD)" = "$EXPECTED_MAIN" ] ||
  stop "AFTER-PR36 checkpoint differs from the verified merge"

[ -z "$(git -C "$CHECKPOINT" status --porcelain)" ] ||
  stop "AFTER-PR36 checkpoint is not clean"

network_retry \
  "fetch-main" \
  90 \
  "$RUN_DIR/fetch-main.out" \
  git -C "$CHECKPOINT" fetch origin main ||
  stop "Unable to refresh origin/main"

[ "$(git -C "$CHECKPOINT" rev-parse origin/main)" = "$EXPECTED_MAIN" ] ||
  stop "origin/main moved beyond the approved PR36 baseline"

network_retry \
  "existing-pr37" \
  45 \
  "$RUN_DIR/existing-pr37.json" \
  gh pr list \
    --repo "$REPO" \
    --state open \
    --head "$BRANCH" \
    --json number,url,headRefName ||
  stop "Unable to inspect existing PR37 state"

EXISTING_PR_URL="$(
  python3 - "$RUN_DIR/existing-pr37.json" <<'PY_EXISTING'
import json
import sys
from pathlib import Path

items = json.loads(
    Path(sys.argv[1]).read_text(encoding="utf-8")
)

print(items[0]["url"] if items else "")
PY_EXISTING
)"

if [ -n "$EXISTING_PR_URL" ]; then
  state_write \
    "PASSED" \
    "completed" \
    "Existing PR37 found and automatic merge remains disabled"

  cat >"$ROOT/final-summary.txt" <<SUMMARY
✅ PR37 ARCHITECT-V3 ALREADY READY

PR URL: $EXISTING_PR_URL
Automatic merge: NO
Direct main change: NO
Production SQL/Supabase/Clerk: UNCHANGED
SUMMARY

  SUCCESS="true"
  exit 0
fi

stage_pass "preflight" "IMMUTABLE_PREFLIGHT_PASSED"

# ------------------------------------------------------------
# Stage 2 — merged-history and P03 evidence audit
# ------------------------------------------------------------

stage "authority-audit" "2/9 — MERGED HISTORY AND AUTHORITY EVIDENCE AUDIT"

for number in 29 30 31 32 33 34 35 36; do
  network_retry \
    "pr-$number" \
    45 \
    "$RUN_DIR/pr-$number.json" \
    gh api "repos/$REPO/pulls/$number" ||
    stop "Unable to read PR #$number"

  sleep 1
done

python3 - "$RUN_DIR" <<'PY_MERGED'
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
rows = []

for number in range(29, 37):
    path = root / f"pr-{number}.json"
    data = json.loads(path.read_text(encoding="utf-8"))

    if data.get("state") != "closed" or not data.get("merged"):
        raise SystemExit(
            f"PR{number} is not confirmed merged"
        )

    rows.append({
        "number": number,
        "title": data.get("title"),
        "head_sha": data.get("head", {}).get("sha"),
        "merge_commit_sha": data.get("merge_commit_sha"),
        "merged_at": data.get("merged_at"),
        "changed_files": data.get("changed_files"),
    })

(root / "merged-pr29-pr36.json").write_text(
    json.dumps(
        rows,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
    ) + "\n",
    encoding="utf-8",
)

print("PR29_THROUGH_PR36_MERGE_AUDIT_PASS")
PY_MERGED

for evidence_path in \
  "supabase/migrations/20260707_vvip_tiger_auth_profile_bridge.sql" \
  "supabase/migrations/20260709_vvip_tiger_atomic_profile_resolver_rpc.sql" \
  "clerk-private-profile.html"
do
  [ -f "$CHECKPOINT/$evidence_path" ] ||
    stop "P03 evidence missing: $evidence_path"
done

grep -Fq \
  "clerk_user_id" \
  "$CHECKPOINT/supabase/migrations/20260707_vvip_tiger_auth_profile_bridge.sql" ||
  stop "Profile bridge does not contain clerk_user_id"

grep -Fq \
  "account_status" \
  "$CHECKPOINT/supabase/migrations/20260707_vvip_tiger_auth_profile_bridge.sql" ||
  stop "Profile bridge does not contain account_status"

grep -Fq \
  "vvip_resolve_own_profile" \
  "$CHECKPOINT/supabase/migrations/20260709_vvip_tiger_atomic_profile_resolver_rpc.sql" ||
  stop "Atomic resolver migration evidence is incomplete"

grep -Fq \
  "vvip_resolve_own_profile" \
  "$CHECKPOINT/clerk-private-profile.html" ||
  stop "Private profile does not reference the atomic resolver"

network_retry \
  "open-prs" \
  45 \
  "$RUN_DIR/open-prs.json" \
  gh pr list \
    --repo "$REPO" \
    --state open \
    --limit 100 \
    --json number,title,headRefName,baseRefName,isDraft,url ||
  stop "Unable to inventory open pull requests"

stage_pass \
  "authority-audit" \
  "MERGED_HISTORY_AND_P03_EVIDENCE_AUDIT_PASSED"

# ------------------------------------------------------------
# Stage 3 — isolated branch/worktree
# ------------------------------------------------------------

stage "isolation" "3/9 — CREATING OR RESUMING ISOLATED PR37 WORKTREE"

if [ -e "$WORKTREE" ]; then
  git -C "$WORKTREE" rev-parse --is-inside-work-tree \
    >/dev/null 2>&1 ||
    stop "PR37 path exists but is not a Git worktree"

  [ "$(git -C "$WORKTREE" branch --show-current)" = "$BRANCH" ] ||
    stop "Existing PR37 worktree uses another branch"
else
  if git -C "$CHECKPOINT" show-ref \
      --verify \
      --quiet "refs/heads/$BRANCH"; then

    git -C "$CHECKPOINT" worktree add \
      "$WORKTREE" \
      "$BRANCH" \
      >"$RUN_DIR/worktree-add.log" 2>&1 ||
      stop "Unable to reopen the existing PR37 branch worktree"

  elif git -C "$CHECKPOINT" ls-remote \
      --exit-code \
      --heads origin "$BRANCH" \
      >/dev/null 2>&1; then

    git -C "$CHECKPOINT" fetch origin "$BRANCH" \
      >"$RUN_DIR/fetch-branch.log" 2>&1 ||
      stop "Unable to fetch existing remote PR37 branch"

    git -C "$CHECKPOINT" branch \
      "$BRANCH" \
      "origin/$BRANCH" ||
      stop "Unable to create local tracking branch"

    git -C "$CHECKPOINT" worktree add \
      "$WORKTREE" \
      "$BRANCH" ||
      stop "Unable to create PR37 tracking worktree"

  else
    git -C "$CHECKPOINT" worktree add \
      -b "$BRANCH" \
      "$WORKTREE" \
      "$EXPECTED_MAIN" \
      >"$RUN_DIR/worktree-create.log" 2>&1 ||
      stop "Unable to create isolated PR37 worktree"
  fi
fi

[ "$(git -C "$WORKTREE" merge-base "$EXPECTED_MAIN" HEAD)" = "$EXPECTED_MAIN" ] ||
  stop "PR37 branch does not descend from the approved baseline"

if [ -n "$(git -C "$WORKTREE" status --porcelain)" ]; then
  if [ -f "$WORKTREE/docs/launch/pr37/CHANGE_CONTROL_MANIFEST.json" ]; then
    python3 - "$WORKTREE" <<'PY_RESUME_SCOPE'
import json
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1])
manifest_path = (
    root /
    "docs/launch/pr37/CHANGE_CONTROL_MANIFEST.json"
)

manifest = json.loads(
    manifest_path.read_text(encoding="utf-8")
)
allowed = set(manifest["allowed_paths"])

changed = set(
    subprocess.run(
        ["git", "-C", str(root), "diff", "--name-only", "HEAD"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.splitlines()
)

changed.update(
    subprocess.run(
        [
            "git", "-C", str(root),
            "ls-files", "--others", "--exclude-standard",
        ],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.splitlines()
)

extra = sorted(changed - allowed)

if extra:
    raise SystemExit(
        "Unexpected resume paths: " + repr(extra)
    )

print("RESUME_SCOPE_PASS")
PY_RESUME_SCOPE
  else
    git -C "$WORKTREE" status --short \
      >"$ROOT/.quarantine/$RUN_ID/unexpected-worktree-state.txt"

    stop "Unexpected PR37 worktree state recorded in metadata quarantine"
  fi
fi

stage_pass "isolation" "ISOLATED_PR37_WORKTREE_READY"

# ------------------------------------------------------------
# Stage 4 — dry run
# ------------------------------------------------------------

stage "dry-run" "4/9 — FULL EXTERNAL DRY RUN"

mkdir -p \
  "$DRY_ROOT/docs/owner-control" \
  "$DRY_ROOT/docs/launch/pr37" \
  "$DRY_ROOT/docs/superpowers/specs" \
  "$DRY_ROOT/docs/superpowers/plans"

cp \
  "$CHECKPOINT/docs/owner-control/phase-status.json" \
  "$DRY_ROOT/docs/owner-control/phase-status.json"

cp \
  "$CHECKPOINT/docs/owner-control/VVIP_TIGER_MASTER_EXECUTION_ROADMAP.yaml" \
  "$DRY_ROOT/docs/owner-control/VVIP_TIGER_MASTER_EXECUTION_ROADMAP.yaml"

cp \
  "$CHECKPOINT/docs/owner-control/VVIP_TIGER_MASTER_EXECUTION_ROADMAP.md" \
  "$DRY_ROOT/docs/owner-control/VVIP_TIGER_MASTER_EXECUTION_ROADMAP.md"

cp \
  "$CHECKPOINT/docs/owner-control/VVIP_TIGER_PHASE_TRACKER.md" \
  "$DRY_ROOT/docs/owner-control/VVIP_TIGER_PHASE_TRACKER.md"

cp \
  "$CHECKPOINT/docs/owner-control/README.md" \
  "$DRY_ROOT/docs/owner-control/README.md"

python3 "$ROOT/reconcile.py" \
  "$DRY_ROOT" \
  "$RUN_DIR" \
  "$EXPECTED_MAIN" \
  >"$RUN_DIR/dry-run-render.log" 2>&1 ||
  {
    cat "$RUN_DIR/dry-run-render.log"
    stop "Dry-run renderer failed"
  }

python3 -m json.tool \
  "$DRY_ROOT/docs/owner-control/phase-status.json" \
  >/dev/null ||
  stop "Dry-run phase-status JSON is invalid"

python3 -m json.tool \
  "$DRY_ROOT/docs/launch/pr37/CHANGE_CONTROL_MANIFEST.json" \
  >/dev/null ||
  stop "Dry-run manifest JSON is invalid"

validate_yaml \
  "$DRY_ROOT/docs/owner-control/VVIP_TIGER_MASTER_EXECUTION_ROADMAP.yaml" \
  >"$RUN_DIR/dry-run-yaml.log" ||
  stop "Dry-run YAML validation failed"

python3 - "$DRY_ROOT" <<'PY_DRY'
import json
import re
import sys
from pathlib import Path

root = Path(sys.argv[1])

status = json.loads(
    (
        root /
        "docs/owner-control/phase-status.json"
    ).read_text(encoding="utf-8")
)

assert status["current_phase"] == "P04"
assert status["last_completed_phase"] == "P03"
assert status["next_authorized_phase"] == "P04"
assert status["execution_lock"] == "P04"

yaml_text = (
    root /
    "docs/owner-control/"
    "VVIP_TIGER_MASTER_EXECUTION_ROADMAP.yaml"
).read_text(encoding="utf-8")

for marker in (
    "current_phase: P04",
    "last_completed_phase: P03",
    "next_authorized_phase: P04",
    "execution_lock: P04",
):
    if marker not in yaml_text:
        raise SystemExit(f"missing YAML marker: {marker}")

roadmap = (
    root /
    "docs/owner-control/"
    "VVIP_TIGER_MASTER_EXECUTION_ROADMAP.md"
).read_text(encoding="utf-8")

tracker = (
    root /
    "docs/owner-control/"
    "VVIP_TIGER_PHASE_TRACKER.md"
).read_text(encoding="utf-8")

if "`P04` — Onboarding and Account Types" not in roadmap:
    raise SystemExit("roadmap does not authorize P04")

if "P04 | Next Authorized Phase" not in tracker:
    raise SystemExit("tracker does not authorize P04")

manifest = json.loads(
    (
        root /
        "docs/launch/pr37/"
        "CHANGE_CONTROL_MANIFEST.json"
    ).read_text(encoding="utf-8")
)

if manifest["scope"] != "documentation-only":
    raise SystemExit("manifest is not documentation-only")

if manifest["automatic_merge_allowed"]:
    raise SystemExit("manifest permits automatic merge")

if manifest["tracked_deletions_allowed"]:
    raise SystemExit("manifest permits tracked deletion")

print("DRY_RUN_AUTHORITY_CONSISTENCY_PASS")
PY_DRY

stage_pass "dry-run" "DRY_RUN_PASSED_100_PERCENT_OF_DEFINED_GATES"

# ------------------------------------------------------------
# Stage 5 — apply deterministic renderer
# ------------------------------------------------------------

stage "apply" "5/9 — APPLYING DETERMINISTIC DOCUMENTATION RECONCILIATION"

python3 "$ROOT/reconcile.py" \
  "$WORKTREE" \
  "$RUN_DIR" \
  "$EXPECTED_MAIN" \
  >"$RUN_DIR/apply-render.log" 2>&1 ||
  {
    cat "$RUN_DIR/apply-render.log"
    stop "Repository renderer failed"
  }

for relative in \
  "docs/owner-control/phase-status.json" \
  "docs/owner-control/VVIP_TIGER_MASTER_EXECUTION_ROADMAP.yaml" \
  "docs/owner-control/VVIP_TIGER_MASTER_EXECUTION_ROADMAP.md" \
  "docs/owner-control/VVIP_TIGER_PHASE_TRACKER.md" \
  "docs/owner-control/README.md" \
  "docs/launch/pr37/CHANGE_CONTROL_MANIFEST.json"
do
  diff -u \
    "$DRY_ROOT/$relative" \
    "$WORKTREE/$relative" \
    >"$RUN_DIR/dry-actual-$(echo "$relative" | tr '/' '_').diff" ||
    stop "Dry-run and actual output differ: $relative"
done

stage_pass "apply" "DETERMINISTIC_RECONCILIATION_APPLIED"

# ------------------------------------------------------------
# Stage 6 — four review rounds
# ------------------------------------------------------------

stage "review-1" "6A/9 — REVIEW 1/4: ARCHITECTURE AND SOURCE OF TRUTH"

python3 - "$WORKTREE" "$RUN_DIR" <<'PY_REVIEW1'
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
evidence = Path(sys.argv[2])

status = json.loads(
    (
        root /
        "docs/owner-control/phase-status.json"
    ).read_text(encoding="utf-8")
)

if (
    status.get("current_phase"),
    status.get("last_completed_phase"),
    status.get("next_authorized_phase"),
    status.get("execution_lock"),
) != ("P04", "P03", "P04", "P04"):
    raise SystemExit("machine-readable phase authority differs")

phases = {
    item["id"]: item["status"]
    for item in status["phases"]
}

expected = {
    "P02": "completed",
    "P03": "completed",
    "P04": "next_authorized",
}

for phase_id, value in expected.items():
    if phases.get(phase_id) != value:
        raise SystemExit(
            f"{phase_id} status differs: {phases.get(phase_id)}"
        )

for number in range(29, 37):
    data = json.loads(
        (evidence / f"pr-{number}.json").read_text(
            encoding="utf-8"
        )
    )

    if not data.get("merged"):
        raise SystemExit(f"PR{number} merge evidence missing")

print("REVIEW_1_ARCHITECTURE_PASS")
PY_REVIEW1

write_review \
  "$WORKTREE/docs/launch/pr37/reviews/ROUND_1_ARCHITECTURE.md" \
  "PR37 Review Round 1 — Architecture and Source of Truth" \
  "Machine-readable and human-readable authority now agree on P02 and P03 as completed and P04 as the proposed next authorized phase. PR29 through PR36 merge evidence was verified. Later foundations are recorded without advancing the execution lock."

stage_pass "review-1" "REVIEW_1_ARCHITECTURE_PASSED"

stage "review-2" "6B/9 — REVIEW 2/4: SECURITY AND PRIVACY"

python3 - "$WORKTREE" <<'PY_REVIEW2'
import json
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1])

manifest = json.loads(
    (
        root /
        "docs/launch/pr37/"
        "CHANGE_CONTROL_MANIFEST.json"
    ).read_text(encoding="utf-8")
)

allowed = set(manifest["allowed_paths"])

changed = set(
    subprocess.run(
        ["git", "-C", str(root), "diff", "--name-only", "HEAD"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.splitlines()
)

changed.update(
    subprocess.run(
        [
            "git", "-C", str(root),
            "ls-files", "--others", "--exclude-standard",
        ],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.splitlines()
)

extra = sorted(changed - allowed)

if extra:
    raise SystemExit(
        "undeclared changed paths: " + repr(extra)
    )

for path in changed:
    if not path.startswith("docs/"):
        raise SystemExit(
            f"non-documentation path changed: {path}"
        )

deleted = subprocess.run(
    [
        "git", "-C", str(root),
        "diff", "--name-only", "--diff-filter=D", "HEAD",
    ],
    check=True,
    capture_output=True,
    text=True,
).stdout.splitlines()

if deleted:
    raise SystemExit(
        "tracked deletions detected: " + repr(deleted)
    )

print("REVIEW_2_SCOPE_AND_DELETION_PASS")
PY_REVIEW2

if git -C "$WORKTREE" diff -- \
    | grep -Eiq \
      'sb_secret_[A-Za-z0-9_-]{10,}|sk_live_[A-Za-z0-9_-]{10,}|BEGIN (RSA |EC )?PRIVATE KEY|service_role[[:space:]]*[:=][[:space:]]*["'\''][A-Za-z0-9._-]+'; then
  stop "Sensitive credential pattern detected"
fi

python3 - "$WORKTREE" <<'PY_CONTROL'
import subprocess
import sys

root = sys.argv[1]

text = subprocess.run(
    ["git", "-C", root, "diff", "--"],
    check=True,
    capture_output=True,
).stdout

for byte in (
    b"\xe2\x80\xaa",
    b"\xe2\x80\xab",
    b"\xe2\x80\xac",
    b"\xe2\x80\xad",
    b"\xe2\x80\xae",
):
    if byte in text:
        raise SystemExit(
            "unsafe bidi control character detected"
        )

print("UNICODE_CONTROL_SCAN_PASS")
PY_CONTROL

write_review \
  "$WORKTREE/docs/launch/pr37/reviews/ROUND_2_SECURITY_PRIVACY.md" \
  "PR37 Review Round 2 — Security and Privacy" \
  "The complete working scope remains documentation-only. No runtime, production, SQL, Supabase, Clerk, migration, Service Role or secret-bearing path changed. No tracked file was deleted. Credential and Unicode-control scans passed."

stage_pass "review-2" "REVIEW_2_SECURITY_PRIVACY_PASSED"

stage "review-3" "6C/9 — REVIEW 3/4: OPERATIONAL RESILIENCE"

python3 "$ROOT/statectl.py" \
  "$STATE" \
  "$STATE_LOCK" \
  selftest \
  >"$RUN_DIR/state-selftest.log" ||
  stop "Atomic state self-test failed"

(
  cd "$WORKTREE"
  bash scripts/qa-smoke.sh
) >"$RUN_DIR/historical-smoke.log" 2>&1 ||
  {
    tail -n 200 "$RUN_DIR/historical-smoke.log"
    stop "Historical smoke failed"
  }

(
  cd "$WORKTREE"
  node --test tests/pr36/*.test.mjs
) >"$RUN_DIR/pr36-regression.log" 2>&1 ||
  {
    tail -n 200 "$RUN_DIR/pr36-regression.log"
    stop "PR36 regression suite failed"
  }

python3 - "$WORKTREE" <<'PY_RUNTIME_SCOPE'
import subprocess
import sys

root = sys.argv[1]

paths = subprocess.run(
    ["git", "-C", root, "diff", "--name-only", "HEAD"],
    check=True,
    capture_output=True,
    text=True,
).stdout.splitlines()

runtime = [
    path
    for path in paths
    if not path.startswith("docs/")
]

if runtime:
    raise SystemExit(
        "runtime paths changed: " + repr(runtime)
    )

print("REVIEW_3_RUNTIME_ISOLATION_PASS")
PY_RUNTIME_SCOPE

write_review \
  "$WORKTREE/docs/launch/pr37/reviews/ROUND_3_RESILIENCE.md" \
  "PR37 Review Round 3 — Operational Resilience" \
  "Atomic state-file self-test passed. Historical smoke passed. The full PR36 Node regression suite passed. Network operations use bounded timeouts, retry and jitter. The watchdog distinguishes transient retry, stale heartbeat and process failure without touching repository content."

stage_pass "review-3" "REVIEW_3_RESILIENCE_PASSED"

stage "review-4" "6D/9 — REVIEW 4/4: FINAL SCOPE AND REGRESSION"

write_review \
  "$WORKTREE/docs/launch/pr37/reviews/ROUND_4_FINAL.md" \
  "PR37 Review Round 4 — Final Scope and Regression" \
  "All preceding review gates passed with fresh observed exits. The final gate verifies exact manifest equality, JSON/YAML validity, documentation consistency, no deletion, no runtime path, clean whitespace and rollback through a normal merge-commit revert only."

cat >"$WORKTREE/docs/launch/pr37/FINAL_REPORT.md" <<EOF
# PR37 — Post-PR36 Roadmap Reconciliation Final Report

## Outcome

- Protocol: \`ARCHITECT-V3\`.
- Base: \`$EXPECTED_MAIN\`.
- Scope: documentation-only.
- P02: completed.
- P03: completed.
- Proposed next authorized phase: P04.
- PR31–PR36 foundations recorded without phase skipping.

## Verification

- Immutable checkpoint: PASS.
- PR29–PR36 merge audit: PASS.
- P03 repository evidence: PASS.
- External dry run: PASS.
- Architecture review: PASS.
- Security and privacy review: PASS.
- Operational resilience review: PASS.
- Historical smoke: PASS.
- PR36 regression suite: PASS.
- Final scope review: PASS.

## Safety boundaries

- Direct main modification: NO.
- Runtime modification: NO.
- Tracked deletion: NO.
- Production SQL applied: NO.
- Remote Supabase changed: NO.
- Clerk changed: NO.
- Service Role introduced: NO.
- Automatic merge: DISABLED.

## Rollback

The proposed documentation commit may be reverted through a normal Git
revert after review. No reset, clean, rebase or force push is authorized.
EOF

python3 -m json.tool \
  "$WORKTREE/docs/owner-control/phase-status.json" \
  >/dev/null ||
  stop "Final phase-status JSON validation failed"

python3 -m json.tool \
  "$WORKTREE/docs/launch/pr37/CHANGE_CONTROL_MANIFEST.json" \
  >/dev/null ||
  stop "Final manifest JSON validation failed"

validate_yaml \
  "$WORKTREE/docs/owner-control/VVIP_TIGER_MASTER_EXECUTION_ROADMAP.yaml" \
  >"$RUN_DIR/final-yaml.log" ||
  stop "Final YAML validation failed"

python3 - "$WORKTREE" <<'PY_FINAL'
import json
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1])

manifest = json.loads(
    (
        root /
        "docs/launch/pr37/"
        "CHANGE_CONTROL_MANIFEST.json"
    ).read_text(encoding="utf-8")
)

allowed = set(manifest["allowed_paths"])

changed = set(
    subprocess.run(
        ["git", "-C", str(root), "diff", "--name-only", "HEAD"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.splitlines()
)

changed.update(
    subprocess.run(
        [
            "git", "-C", str(root),
            "ls-files", "--others", "--exclude-standard",
        ],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.splitlines()
)

if changed != allowed:
    raise SystemExit(
        "exact scope mismatch; "
        f"missing={sorted(allowed-changed)!r}, "
        f"extra={sorted(changed-allowed)!r}"
    )

if manifest["allowed_path_count"] != len(allowed):
    raise SystemExit("manifest path count is inaccurate")

for path in changed:
    if not path.startswith("docs/"):
        raise SystemExit(
            f"non-doc path in final scope: {path}"
        )

deleted = subprocess.run(
    [
        "git", "-C", str(root),
        "diff", "--name-only", "--diff-filter=D", "HEAD",
    ],
    check=True,
    capture_output=True,
    text=True,
).stdout.splitlines()

if deleted:
    raise SystemExit(
        "tracked deletion in final scope: " + repr(deleted)
    )

print("EXACT_MANIFEST_SCOPE_PASS")
print("NO_TRACKED_DELETION_PASS")
print("DOCUMENTATION_ONLY_SCOPE_PASS")
PY_FINAL

git -C "$WORKTREE" diff --check ||
  stop "Whitespace validation failed"

stage_pass "review-4" "FOUR_REVIEW_ROUNDS_AND_FINAL_SCOPE_PASSED"

# ------------------------------------------------------------
# Stage 7 — commit
# ------------------------------------------------------------

stage "commit" "7/9 — CREATING ONE DOCUMENTATION COMMIT"

git -C "$WORKTREE" add \
  docs/launch/pr37 \
  docs/owner-control/README.md \
  docs/owner-control/VVIP_TIGER_MASTER_EXECUTION_ROADMAP.md \
  docs/owner-control/VVIP_TIGER_MASTER_EXECUTION_ROADMAP.yaml \
  docs/owner-control/VVIP_TIGER_PHASE_TRACKER.md \
  docs/owner-control/phase-status.json \
  docs/superpowers/specs/2026-07-15-pr37-post-pr36-roadmap-reconciliation-design.md \
  docs/superpowers/plans/2026-07-15-pr37-post-pr36-roadmap-reconciliation.md

python3 - "$WORKTREE" <<'PY_STAGED'
import json
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1])

manifest = json.loads(
    (
        root /
        "docs/launch/pr37/"
        "CHANGE_CONTROL_MANIFEST.json"
    ).read_text(encoding="utf-8")
)

expected = sorted(manifest["allowed_paths"])

staged = sorted(
    subprocess.run(
        [
            "git", "-C", str(root),
            "diff", "--cached", "--name-only",
        ],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.splitlines()
)

if staged != expected:
    raise SystemExit(
        "staged scope mismatch: " + repr(staged)
    )

deleted = subprocess.run(
    [
        "git", "-C", str(root),
        "diff", "--cached",
        "--name-only", "--diff-filter=D",
    ],
    check=True,
    capture_output=True,
    text=True,
).stdout.splitlines()

if deleted:
    raise SystemExit(
        "staged tracked deletion detected"
    )

print("EXACT_STAGED_SCOPE_PASS")
PY_STAGED

git -C "$WORKTREE" diff --cached --check ||
  stop "Staged whitespace validation failed"

if git -C "$WORKTREE" diff --cached --quiet; then
  if [ "$(git -C "$WORKTREE" rev-list --count "$EXPECTED_MAIN..HEAD")" -eq 0 ]; then
    stop "No documentation changes exist to commit"
  fi
else
  git -C "$WORKTREE" \
    -c user.name="vvipautoparts-blip" \
    -c user.email="294954557+vvipautoparts-blip@users.noreply.github.com" \
    commit \
    -m "docs: reconcile roadmap authority after PR36" \
    >"$RUN_DIR/commit.log" 2>&1 ||
    {
      cat "$RUN_DIR/commit.log"
      stop "Documentation commit failed"
    }
fi

NEW_HEAD="$(git -C "$WORKTREE" rev-parse HEAD)"

[ "$NEW_HEAD" != "$EXPECTED_MAIN" ] ||
  stop "Commit did not advance the PR37 branch"

[ -z "$(git -C "$WORKTREE" status --porcelain)" ] ||
  stop "PR37 worktree is not clean after commit"

stage_pass "commit" "DOCUMENTATION_COMMIT_CREATED"

# ------------------------------------------------------------
# Stage 8 — detached verification and push
# ------------------------------------------------------------

stage "detached-push" "8/9 — DETACHED VERIFICATION AND SAFE PUSH"

DETACHED="$ROOT/worktrees/pr37-detached-$RUN_ID"

git -C "$CHECKPOINT" worktree add \
  --detach \
  "$DETACHED" \
  "$NEW_HEAD" \
  >"$RUN_DIR/detached-create.log" 2>&1 ||
  stop "Unable to create detached verification worktree"

python3 -m json.tool \
  "$DETACHED/docs/owner-control/phase-status.json" \
  >/dev/null ||
  stop "Detached JSON verification failed"

python3 -m json.tool \
  "$DETACHED/docs/launch/pr37/CHANGE_CONTROL_MANIFEST.json" \
  >/dev/null ||
  stop "Detached manifest verification failed"

validate_yaml \
  "$DETACHED/docs/owner-control/VVIP_TIGER_MASTER_EXECUTION_ROADMAP.yaml" \
  >"$RUN_DIR/detached-yaml.log" ||
  stop "Detached YAML verification failed"

(
  cd "$DETACHED"
  bash scripts/qa-smoke.sh
  node --test tests/pr36/*.test.mjs
) >"$RUN_DIR/detached-regression.log" 2>&1 ||
  {
    tail -n 220 "$RUN_DIR/detached-regression.log"
    stop "Detached regression verification failed"
  }

python3 - \
  "$DETACHED" \
  "$EXPECTED_MAIN" <<'PY_DETACHED'
import json
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1])
base = sys.argv[2]

manifest = json.loads(
    (
        root /
        "docs/launch/pr37/"
        "CHANGE_CONTROL_MANIFEST.json"
    ).read_text(encoding="utf-8")
)

expected = set(manifest["allowed_paths"])

actual = set(
    subprocess.run(
        [
            "git", "-C", str(root),
            "diff", base, "--name-only",
        ],
        check=True,
        capture_output=True,
        text=True,
    ).stdout.splitlines()
)

if actual != expected:
    raise SystemExit(
        "detached committed scope differs from manifest"
    )

print("DETACHED_EXACT_SCOPE_PASS")
PY_DETACHED

git -C "$CHECKPOINT" worktree remove \
  --force "$DETACHED" ||
  stop "Unable to remove controller-owned detached worktree"

DETACHED=""

network_retry \
  "push-pr37" \
  120 \
  "$RUN_DIR/push.out" \
  git -C "$WORKTREE" push \
    --set-upstream origin "$BRANCH" ||
  stop "Push failed after bounded network retries"

REMOTE_HEAD="$(
  git -C "$WORKTREE" ls-remote \
    --heads origin "$BRANCH" |
  awk '{print $1}'
)"

[ "$REMOTE_HEAD" = "$NEW_HEAD" ] ||
  stop "Remote PR37 branch differs from verified commit"

stage_pass "detached-push" "DETACHED_VERIFICATION_AND_PUSH_PASSED"

# ------------------------------------------------------------
# Stage 9 — open PR without merge
# ------------------------------------------------------------

stage "open-pr" "9/9 — OPENING REVIEWABLE PR WITHOUT MERGE"

cat >"$RUN_DIR/pr-body.md" <<EOF
## PR37 — Post-PR36 Roadmap Authority Reconciliation

### Purpose

Reconcile the official phase authority after PR36 without modifying
runtime, Production, Supabase, Clerk, SQL, migrations, RLS, Storage
Policies or Service Roles.

### Proposed authority

- P02: completed.
- P03: completed.
- P04: next authorized phase.
- PR31–PR36 foundations are recorded without phase skipping.

### Verification

- Immutable AFTER-PR36 baseline: PASS.
- PR29–PR36 merge audit: PASS.
- P03 repository evidence: PASS.
- External dry run: PASS.
- Architecture review: PASS.
- Security and privacy review: PASS.
- Operational resilience review: PASS.
- Historical smoke: PASS.
- PR36 regression suite: PASS.
- Detached exact-scope verification: PASS.

### Safety boundaries

- Documentation-only scope.
- No direct main modification.
- No tracked deletion.
- No Runtime changes.
- No Production SQL.
- No remote Supabase change.
- No Clerk change.
- No Service Role.
- No automatic merge.

### Verified commit

\`$NEW_HEAD\`

### Values

Amanah, justice, transparency, privacy and disciplined execution without
false success claims.
EOF

network_retry \
  "existing-pr-after-push" \
  45 \
  "$RUN_DIR/pr-after-push.json" \
  gh pr list \
    --repo "$REPO" \
    --state open \
    --head "$BRANCH" \
    --json number,url,headRefName ||
  stop "Unable to inspect PR after push"

PR_URL="$(
  python3 - "$RUN_DIR/pr-after-push.json" <<'PY_PR_URL'
import json
import sys
from pathlib import Path

items = json.loads(
    Path(sys.argv[1]).read_text(encoding="utf-8")
)

print(items[0]["url"] if items else "")
PY_PR_URL
)"

if [ -z "$PR_URL" ]; then
  if network_retry \
      "create-pr37" \
      90 \
      "$RUN_DIR/create-pr.out" \
      gh pr create \
        --repo "$REPO" \
        --base main \
        --head "$BRANCH" \
        --title "PR37 — Post-PR36 Roadmap Authority Reconciliation" \
        --body-file "$RUN_DIR/pr-body.md"; then

    PR_URL="$(tail -n 1 "$RUN_DIR/create-pr.out")"
  else
    network_retry \
      "recover-pr37" \
      45 \
      "$RUN_DIR/recover-pr37.json" \
      gh pr list \
        --repo "$REPO" \
        --state open \
        --head "$BRANCH" \
        --json number,url ||
      stop "PR creation failed and recovery query failed"

    PR_URL="$(
      python3 - "$RUN_DIR/recover-pr37.json" <<'PY_RECOVER'
import json
import sys
from pathlib import Path

items = json.loads(
    Path(sys.argv[1]).read_text(encoding="utf-8")
)
print(items[0]["url"] if items else "")
PY_RECOVER
    )"

    [ -n "$PR_URL" ] ||
      stop "PR creation failed and no existing PR was found"
  fi
fi

network_retry \
  "final-pr-verification" \
  45 \
  "$RUN_DIR/final-pr.json" \
  gh pr view "$PR_URL" \
    --repo "$REPO" \
    --json number,state,isDraft,url,headRefName,baseRefName,mergeStateStatus ||
  stop "Unable to verify the opened PR"

python3 - \
  "$RUN_DIR/final-pr.json" \
  "$BRANCH" <<'PY_FINAL_PR'
import json
import sys
from pathlib import Path

data = json.loads(
    Path(sys.argv[1]).read_text(encoding="utf-8")
)

errors = []

if data.get("state") != "OPEN":
    errors.append("PR is not open")

if data.get("headRefName") != sys.argv[2]:
    errors.append("PR head branch differs")

if data.get("baseRefName") != "main":
    errors.append("PR base is not main")

if errors:
    raise SystemExit("; ".join(errors))

print("PR_OPEN_UNMERGED_VERIFICATION_PASS")
print("PR_NUMBER:", data.get("number"))
print("PR_URL:", data.get("url"))
PY_FINAL_PR

# Smart cleanup: only controller-owned V2-TEMP artifacts.
find "$ROOT/tmp" \
  -maxdepth 1 \
  -type f \
  -name 'V2-TEMP-*' \
  -mmin +30 \
  -print0 2>/dev/null |
while IFS= read -r -d '' temp_file; do
  mv \
    "$temp_file" \
    "$ROOT/.quarantine/$RUN_ID/" ||
    true
done

cat >"$ROOT/final-summary.txt" <<SUMMARY
✅ PR37 ARCHITECT-V3 PASSED

PR URL: $PR_URL
Commit: $NEW_HEAD
Branch: $BRANCH

P02: completed
P03: completed
P04: proposed next authorized phase

Four reviews: PASS
Dry run: PASS
Historical smoke: PASS
PR36 regression: PASS
Detached verification: PASS

Automatic merge: NO
Direct main change: NO
Tracked deletion: NO
Production SQL/Supabase/Clerk: UNCHANGED

Evidence: $RUN_DIR
SUMMARY

state_write \
  "PASSED" \
  "completed" \
  "PR37 opened successfully for review; automatic merge disabled"

SUCCESS="true"

echo
echo "======================================================"
echo " ✅ PR37 ARCHITECT-V3 ZERO-TOUCH EXECUTION PASSED"
echo "======================================================"
echo "PR URL: $PR_URL"
echo "Commit: $NEW_HEAD"
echo "Dry run: PASS"
echo "Four reviews: PASS"
echo "Historical smoke: PASS"
echo "PR36 regression: PASS"
echo "Automatic merge: NO"
echo "Direct main change: NO"
echo "Tracked deletion: NO"
echo "Production SQL/Supabase/Clerk: UNCHANGED"
echo "Evidence: $RUN_DIR"
echo "======================================================"
