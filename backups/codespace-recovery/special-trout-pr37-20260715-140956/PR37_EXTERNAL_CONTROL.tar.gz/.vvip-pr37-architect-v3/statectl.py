#!/usr/bin/env python3
import datetime as dt
import fcntl
import json
import os
import sys
from pathlib import Path


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def atomic_write(path: Path, data: dict):
    temp = path.with_name(path.name + f".tmp.{os.getpid()}")
    temp.write_text(
        json.dumps(
            data,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        ) + "\n",
        encoding="utf-8",
    )
    os.replace(temp, path)


def load(path: Path):
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def main():
    if len(sys.argv) < 4:
        raise SystemExit(
            "usage: statectl.py STATE LOCK ACTION [ARGS...]"
        )

    state_path = Path(sys.argv[1])
    lock_path = Path(sys.argv[2])
    action = sys.argv[3]

    state_path.parent.mkdir(parents=True, exist_ok=True)
    lock_path.parent.mkdir(parents=True, exist_ok=True)

    with lock_path.open("a+", encoding="utf-8") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        data = load(state_path)

        if action == "write":
            if len(sys.argv) < 10:
                raise SystemExit("write requires 6 arguments")

            status = sys.argv[4]
            stage = sys.argv[5]
            message = sys.argv[6]
            pid = int(sys.argv[7])
            run_id = sys.argv[8]
            evidence = sys.argv[9]

            completed = list(data.get("completed_stages", []))

            if status == "STAGE_PASSED":
                if stage not in completed:
                    completed.append(stage)
                status = "RUNNING"

            created_at = data.get("created_at") or now()

            data.update({
                "schema": 3,
                "protocol": "ARCHITECT-V3",
                "run_id": run_id,
                "status": status,
                "stage": stage,
                "message": message,
                "pid": pid,
                "created_at": created_at,
                "updated_at": now(),
                "last_heartbeat": now(),
                "completed_stages": completed,
                "evidence": evidence,
                "automatic_merge": False,
                "direct_main_change": False,
                "production_sql": False,
                "remote_supabase_changed": False,
                "clerk_changed": False,
                "tracked_deletion": False,
            })

            atomic_write(state_path, data)
            return

        if action == "heartbeat":
            pid = int(sys.argv[4])

            if data.get("status") in {
                "PASSED",
                "FAILED",
            }:
                return

            data["pid"] = pid
            data["last_heartbeat"] = now()
            data["updated_at"] = now()
            atomic_write(state_path, data)
            return

        if action == "field":
            key = sys.argv[4]
            value = data.get(key)

            if isinstance(value, (dict, list)):
                print(json.dumps(value, ensure_ascii=False))
            elif value is None:
                print("")
            else:
                print(value)
            return

        if action == "read":
            print(
                json.dumps(
                    data,
                    ensure_ascii=False,
                    indent=2,
                    sort_keys=True,
                )
            )
            return

        if action == "selftest":
            original = dict(data)

            probe = dict(data)
            probe["_selftest"] = {
                "pid": os.getpid(),
                "timestamp": now(),
            }

            atomic_write(state_path, probe)
            reread = load(state_path)

            if "_selftest" not in reread:
                raise SystemExit("atomic state self-test failed")

            atomic_write(state_path, original)
            print("STATE_ATOMIC_SELFTEST_PASS")
            return

        raise SystemExit(f"unknown action: {action}")


if __name__ == "__main__":
    main()
