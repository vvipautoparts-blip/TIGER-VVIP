#!/usr/bin/env python3
import datetime as dt
import fcntl
import json
import os
import sys
import time
from pathlib import Path


STATE = Path(sys.argv[1])
STATE_LOCK = Path(sys.argv[2])
WATCHDOG_LOCK = Path(sys.argv[3])


def now():
    return dt.datetime.now(dt.timezone.utc)


def atomic_write(path, data):
    temp = path.with_name(path.name + f".watchdog.{os.getpid()}")
    temp.write_text(
        json.dumps(
            data,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        ) + "\n",
        encoding="utf-8",
    )
    os.replace(temp, path)


def read_state():
    if not STATE.exists():
        return {}
    try:
        return json.loads(STATE.read_text(encoding="utf-8"))
    except Exception:
        return {}


WATCHDOG_LOCK.parent.mkdir(parents=True, exist_ok=True)

with WATCHDOG_LOCK.open("a+", encoding="utf-8") as owner_lock:
    try:
        fcntl.flock(
            owner_lock.fileno(),
            fcntl.LOCK_EX | fcntl.LOCK_NB,
        )
    except BlockingIOError:
        raise SystemExit(0)

    while True:
        time.sleep(15)

        if not STATE.exists():
            continue

        with STATE_LOCK.open("a+", encoding="utf-8") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            data = read_state()

            status = data.get("status")

            if status in {"PASSED", "FAILED"}:
                raise SystemExit(0)

            heartbeat = data.get("last_heartbeat")
            pid = data.get("pid")

            try:
                heartbeat_time = dt.datetime.fromisoformat(heartbeat)
                age = (now() - heartbeat_time).total_seconds()
            except Exception:
                age = 999999

            alive = (
                isinstance(pid, int)
                and pid > 0
                and os.path.exists(f"/proc/{pid}")
            )

            if age > 120 and alive:
                data["status"] = "STALLED"
                data["message"] = (
                    "Runner is alive but heartbeat is stale; "
                    "watchdog is preserving the worktree for inspection."
                )
                data["updated_at"] = now().isoformat()
                atomic_write(STATE, data)

            elif age > 120 and not alive:
                data["status"] = "FAILED"
                data["stage"] = "watchdog-safe-stop"
                data["message"] = (
                    "Runner process is no longer alive. "
                    "No automatic merge was permitted."
                )
                data["updated_at"] = now().isoformat()
                atomic_write(STATE, data)
                raise SystemExit(1)
