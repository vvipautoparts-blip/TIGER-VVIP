#!/usr/bin/env python3
import json
import re
import sys
from pathlib import Path


root = Path(sys.argv[1])
evidence = Path(sys.argv[2])
expected_main = sys.argv[3]
today = "2026-07-15"

phase_status_path = (
    root / "docs/owner-control/phase-status.json"
)
roadmap_yaml_path = (
    root /
    "docs/owner-control/"
    "VVIP_TIGER_MASTER_EXECUTION_ROADMAP.yaml"
)
roadmap_md_path = (
    root /
    "docs/owner-control/"
    "VVIP_TIGER_MASTER_EXECUTION_ROADMAP.md"
)
tracker_path = (
    root /
    "docs/owner-control/"
    "VVIP_TIGER_PHASE_TRACKER.md"
)
readme_path = root / "docs/owner-control/README.md"

manifest_path = (
    root /
    "docs/launch/pr37/"
    "CHANGE_CONTROL_MANIFEST.json"
)
spec_path = (
    root /
    "docs/superpowers/specs/"
    "2026-07-15-pr37-post-pr36-roadmap-"
    "reconciliation-design.md"
)
plan_path = (
    root /
    "docs/superpowers/plans/"
    "2026-07-15-pr37-post-pr36-roadmap-"
    "reconciliation.md"
)

required_existing = [
    phase_status_path,
    roadmap_yaml_path,
    roadmap_md_path,
    tracker_path,
    readme_path,
]

for path in required_existing:
    if not path.exists():
        raise SystemExit(f"required file missing: {path}")

allowed_paths = sorted([
    "docs/launch/pr37/CHANGE_CONTROL_MANIFEST.json",
    "docs/launch/pr37/FINAL_REPORT.md",
    "docs/launch/pr37/reviews/ROUND_1_ARCHITECTURE.md",
    "docs/launch/pr37/reviews/ROUND_2_SECURITY_PRIVACY.md",
    "docs/launch/pr37/reviews/ROUND_3_RESILIENCE.md",
    "docs/launch/pr37/reviews/ROUND_4_FINAL.md",
    "docs/owner-control/README.md",
    "docs/owner-control/VVIP_TIGER_MASTER_EXECUTION_ROADMAP.md",
    "docs/owner-control/VVIP_TIGER_MASTER_EXECUTION_ROADMAP.yaml",
    "docs/owner-control/VVIP_TIGER_PHASE_TRACKER.md",
    "docs/owner-control/phase-status.json",
    (
        "docs/superpowers/plans/"
        "2026-07-15-pr37-post-pr36-roadmap-"
        "reconciliation.md"
    ),
    (
        "docs/superpowers/specs/"
        "2026-07-15-pr37-post-pr36-roadmap-"
        "reconciliation-design.md"
    ),
])

# ------------------------------------------------------------
# phase-status.json
# ------------------------------------------------------------

data = json.loads(
    phase_status_path.read_text(encoding="utf-8")
)

current = data.get("current_phase")

if current not in {"P02", "P04"}:
    raise SystemExit(
        f"unexpected current phase before reconciliation: {current}"
    )

data["schema_version"] = max(
    int(data.get("schema_version", 2)),
    3,
)
data["updated_on"] = today
data["current_phase"] = "P04"
data["last_completed_phase"] = "P03"
data["next_authorized_phase"] = "P04"
data["execution_lock"] = "P04"

phase_by_id = {
    phase.get("id"): phase
    for phase in data.get("phases", [])
}

for phase_id in ("P02", "P03", "P04"):
    if phase_id not in phase_by_id:
        raise SystemExit(
            f"required phase missing from phase-status: {phase_id}"
        )

phase_by_id["P02"]["status"] = "completed"
phase_by_id["P03"]["status"] = "completed"
phase_by_id["P04"]["status"] = "next_authorized"

data["post_pr36_reconciliation"] = {
    "protocol": "ARCHITECT-V3",
    "reconciliation_branch": (
        "docs/pr37-post-pr36-roadmap-reconciliation"
    ),
    "base_commit": expected_main,
    "evidence": {
        "p02": [
            "PR29 — Unified Home and Marketplace Experience",
            "PR30 — Visual Navigation and Resilience Stabilization",
        ],
        "p03": [
            (
                "supabase/migrations/"
                "20260707_vvip_tiger_auth_profile_bridge.sql"
            ),
            (
                "supabase/migrations/"
                "20260709_vvip_tiger_atomic_profile_resolver_rpc.sql"
            ),
            "clerk-private-profile.html",
        ],
        "later_foundations_do_not_advance_lock": [
            "PR31 — Create Listing Safe Shell",
            "PR32 — Draft Preview Integration",
            "PR33 — Publish Readiness",
            "PR34 — Listing Contract Foundation",
            "PR35 — Owner Control and Tiger Care Foundation",
            "PR36 — Secure Seven-Photo Processing",
        ],
    },
    "next_authorized_phase": "P04",
    "automatic_merge": False,
    "runtime_change_authorized_by_this_pr": False,
}

phase_status_path.write_text(
    json.dumps(
        data,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
    ) + "\n",
    encoding="utf-8",
)

# ------------------------------------------------------------
# YAML source of truth
# ------------------------------------------------------------

yaml_text = roadmap_yaml_path.read_text(encoding="utf-8")


def replace_top_scalar(text, key, value):
    pattern = rf"(?m)^{re.escape(key)}:\s*\S+\s*$"
    replacement = f"{key}: {value}"
    new_text, count = re.subn(
        pattern,
        replacement,
        text,
        count=1,
    )

    if count == 0:
        if replacement in text:
            return text
        raise SystemExit(f"YAML scalar missing: {key}")

    return new_text


def replace_phase_status(text, phase_id, value):
    pattern = (
        rf"(?ms)"
        rf"(^  - id: {re.escape(phase_id)}\n"
        rf".*?^    status: )\S+"
    )

    new_text, count = re.subn(
        pattern,
        rf"\g<1>{value}",
        text,
        count=1,
    )

    if count == 0:
        block_check = re.search(
            rf"(?ms)^  - id: {re.escape(phase_id)}\n"
            rf".*?^    status: {re.escape(value)}$",
            text,
        )
        if block_check:
            return text
        raise SystemExit(
            f"YAML phase status missing: {phase_id}"
        )

    return new_text


yaml_text = replace_top_scalar(
    yaml_text,
    "current_phase",
    "P04",
)
yaml_text = replace_top_scalar(
    yaml_text,
    "last_completed_phase",
    "P03",
)
yaml_text = replace_top_scalar(
    yaml_text,
    "next_authorized_phase",
    "P04",
)
yaml_text = replace_top_scalar(
    yaml_text,
    "execution_lock",
    "P04",
)

yaml_text = replace_phase_status(
    yaml_text,
    "P02",
    "completed",
)
yaml_text = replace_phase_status(
    yaml_text,
    "P03",
    "completed",
)
yaml_text = replace_phase_status(
    yaml_text,
    "P04",
    "next_authorized",
)

yaml_marker = "post_pr36_reconciliation:"

if yaml_marker not in yaml_text:
    yaml_text = yaml_text.rstrip() + f"""

post_pr36_reconciliation:
  protocol: ARCHITECT-V3
  reconciliation_branch: docs/pr37-post-pr36-roadmap-reconciliation
  base_commit: {expected_main}
  completed_sequence:
    - P02
    - P03
  next_authorized_phase: P04
  later_foundations:
    - PR31_create_listing_shell
    - PR32_draft_preview
    - PR33_publish_readiness
    - PR34_listing_contract
    - PR35_owner_control_tiger_care_foundation
    - PR36_secure_seven_photo_processing
  foundation_rule: later_foundations_do_not_advance_execution_lock
  runtime_change_authorized: false
  automatic_merge: false
"""

roadmap_yaml_path.write_text(
    yaml_text,
    encoding="utf-8",
)

# ------------------------------------------------------------
# Human-readable roadmap
# ------------------------------------------------------------

roadmap = roadmap_md_path.read_text(encoding="utf-8")
roadmap = roadmap.replace(
    "- التاريخ: 2026-07-10",
    f"- التاريخ: {today}",
    1,
)


def replace_between(text, start, end, replacement):
    start_index = text.find(start)
    end_index = text.find(end)

    if start_index < 0 or end_index < 0:
        raise SystemExit(
            f"unable to replace section: {start} -> {end}"
        )

    if end_index <= start_index:
        raise SystemExit(
            f"invalid section order: {start} -> {end}"
        )

    return (
        text[:start_index]
        + replacement.rstrip()
        + "\n\n"
        + text[end_index:]
    )


new_status_sections = f"""## الحالة الحالية

تمت مصالحة حالة التنفيذ بعد دمج PR29 حتى PR36.

الحالة الموثقة:

- `P02` — App Shell and Navigation Architecture = completed.
- `P03` — Clerk ↔ Supabase Profile Identity Bridge = completed.
- PR31–PR36 تمثل أسسًا موثقة لمراحل لاحقة، لكنها لا تتجاوز
  ترتيب المراحل ولا تغيّر قفل التنفيذ تلقائيًا.
- `main` المرجعي عند بداية المصالحة:
  `{expected_main}`.
- لا Runtime أو SQL أو Supabase أو Clerk أو Production changes
  ضمن PR37.

## المرحلة المسموح بها الآن

- `P04` — Onboarding and Account Types.
- الحالة: Next Authorized Phase.
- لا يبدأ Runtime الخاص بها قبل مراجعة PR37 ودمجه والتحقق
  من `main`.
"""

roadmap = replace_between(
    roadmap,
    "## الحالة الحالية",
    "## خارطة المراحل",
    new_status_sections,
)


def replace_markdown_phase_status(text, phase_id, value):
    pattern = (
        rf"(?ms)"
        rf"(^### {re.escape(phase_id)}\n"
        rf".*?^- الحالة: `)[^`]+(`)"
    )

    new_text, count = re.subn(
        pattern,
        rf"\g<1>{value}\g<2>",
        text,
        count=1,
    )

    if count == 0:
        expected = (
            f"### {phase_id}"
        )
        if expected not in text:
            raise SystemExit(
                f"roadmap phase missing: {phase_id}"
            )

    return new_text


roadmap = replace_markdown_phase_status(
    roadmap,
    "P02",
    "completed",
)
roadmap = replace_markdown_phase_status(
    roadmap,
    "P03",
    "completed",
)
roadmap = replace_markdown_phase_status(
    roadmap,
    "P04",
    "next_authorized",
)

roadmap_marker = (
    "## مصالحة ما بعد PR36 — ARCHITECT-V3"
)

if roadmap_marker not in roadmap:
    roadmap = roadmap.rstrip() + f"""

{roadmap_marker}

- المرجع: `{expected_main}`.
- PR29 وPR30 يغلقان App Shell والتنقل المرئي.
- Profile Bridge وAtomic Profile Resolver يغلقان P03 على مستوى
  المستودع، دون الادعاء بتطبيق SQL إنتاجي جديد.
- PR31 حتى PR36 موثقة كأسس لاحقة، ولا تُستخدم للقفز فوق P04.
- المرحلة المقترحة التالية للمراجعة: `P04`.
- PR37 توثيقي فقط.
- الدمج التلقائي: ممنوع.
- الحذف المتتبع: ممنوع.
- Production SQL / Supabase / Clerk: خارج النطاق.
"""

roadmap_md_path.write_text(
    roadmap,
    encoding="utf-8",
)

# ------------------------------------------------------------
# Phase tracker
# ------------------------------------------------------------

tracker = tracker_path.read_text(encoding="utf-8")
tracker = re.sub(
    r"(?m)^آخر تحديث:\s*.*$",
    f"آخر تحديث: {today}",
    tracker,
    count=1,
)

tracker_section = f"""## خارطة التنفيذ الرسمية الحالية

هذه الحالة هي المرجع اليومي المختصر لخارطة التنفيذ الرسمية،
وتعلو على أي ملخصات تاريخية أقدم داخل الملف.

| المرحلة | الحالة | الملاحظة |
|---|---|---|
| P00 | Completed and Post-Merge Verified | Discovery Experience Shell |
| P00.1 | Completed and Post-Merge Verified | Master Execution Roadmap |
| P01 | Completed and Post-Merge Verified | Repository Audit and Gap Matrix |
| P02 | Completed and Reconciled | PR29 وPR30 |
| P03 | Completed and Reconciled | Clerk/Supabase Profile Bridge وAtomic Resolver |
| P04 | Next Authorized Phase, Not Started | Onboarding and Account Types |
| P05-P34 | Pending / Historical Foundations Recorded | لا تتجاوز قفل P04 |

ملاحظة تنفيذية:

- PR31 حتى PR36 تحتوي أسسًا نافعة لمراحل لاحقة.
- وجود أساس لاحق لا يعني إغلاق المرحلة الكاملة.
- لا يبدأ P04 قبل دمج PR37 والتحقق بعد الدمج.
- لا يصرح PR37 بأي Runtime أو Production أو SQL change.
"""

tracker = replace_between(
    tracker,
    "## خارطة التنفيذ الرسمية الحالية",
    "## المراحل",
    tracker_section,
)

replacements = {
    (
        "| 0 | Owner Runtime Control Center | ⬜ | "
        "يحتاج صلاحية مالك حقيقية |"
    ): (
        "| 0 | Owner Runtime Control Center | 🟡 | "
        "أساس آمن موجود عبر PR35 |"
    ),
    (
        "| 2 | App Shell وFeed | 🟡 | أجزاء أولية فقط |"
    ): (
        "| 2 | App Shell وFeed | ✅ | "
        "تمت المصالحة عبر PR29 وPR30 |"
    ),
    (
        "| 4 | محرك الإعلانات | ⬜ | "
        "إنشاء وتفاصيل وتعديل وحذف |"
    ): (
        "| 4 | محرك الإعلانات | 🟡 | "
        "أساس محلي عبر PR31–PR34؛ Backend لاحق |"
    ),
    (
        "| 4 | خط صور 7 صور | ⬜ | قص وضغط وتخزين |"
    ): (
        "| 4 | خط صور 7 صور | 🟡 | "
        "المعالجة المحلية اكتملت عبر PR36؛ التخزين لاحق |"
    ),
    (
        "| 7 | Tiger Care | ⬜ | معتمد |"
    ): (
        "| 7 | Tiger Care | 🟡 | "
        "الأساس الآمن موجود عبر PR35 |"
    ),
}

for old, new in replacements.items():
    if old in tracker:
        tracker = tracker.replace(old, new, 1)

tracker_marker = "## سجل مصالحة PR37"

if tracker_marker not in tracker:
    tracker = tracker.rstrip() + f"""

{tracker_marker}

- Protocol: `ARCHITECT-V3`.
- Base: `{expected_main}`.
- P02: completed.
- P03: completed.
- P04: next authorized.
- PR31–PR36: historical foundations recorded.
- Runtime mutation: none.
- Automatic merge: disabled.
"""

tracker_path.write_text(
    tracker,
    encoding="utf-8",
)

# ------------------------------------------------------------
# README navigation
# ------------------------------------------------------------

readme = readme_path.read_text(
    encoding="utf-8",
    errors="replace",
)

readme_marker = "## Post-PR36 Roadmap Reconciliation"

if readme_marker not in readme:
    readme = readme.rstrip() + f"""

{readme_marker}

- [PR37 Change Control Manifest](../launch/pr37/CHANGE_CONTROL_MANIFEST.json)
- [PR37 Final Report](../launch/pr37/FINAL_REPORT.md)
- Base commit: `{expected_main}`
- Scope: documentation-only authority reconciliation.
- Proposed next authorized phase: `P04`.
- Automatic merge: disabled.
"""

readme_path.write_text(
    readme,
    encoding="utf-8",
)

# ------------------------------------------------------------
# Manifest
# ------------------------------------------------------------

manifest_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

manifest = {
    "schema": 1,
    "project": "VVIP TIGER",
    "protocol": "ARCHITECT-V3",
    "phase": "PR37 post-PR36 roadmap reconciliation",
    "base_sha": expected_main,
    "branch": (
        "docs/pr37-post-pr36-roadmap-reconciliation"
    ),
    "scope": "documentation-only",
    "allowed_paths": allowed_paths,
    "allowed_path_count": len(allowed_paths),
    "forbidden_paths": [
        ".github/workflows/",
        "auth.js",
        "clerk-private-profile.html",
        "scripts/",
        "styles/",
        "supabase/",
        "migrations/",
        "backups/",
        "index.html",
        "private-profile-p03.html",
    ],
    "tracked_deletions_allowed": False,
    "runtime_changes_allowed": False,
    "production_sql_allowed": False,
    "remote_supabase_changes_allowed": False,
    "clerk_changes_allowed": False,
    "service_role_allowed": False,
    "automatic_merge_allowed": False,
    "required_reviews": [
        "architecture",
        "security_privacy",
        "resilience",
        "final_scope_regression",
    ],
    "next_authorized_phase_proposal": "P04",
}

manifest_path.write_text(
    json.dumps(
        manifest,
        ensure_ascii=False,
        indent=2,
        sort_keys=True,
    ) + "\n",
    encoding="utf-8",
)

# ------------------------------------------------------------
# Design and implementation plan
# ------------------------------------------------------------

spec_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

spec_path.write_text(
    f"""# PR37 Post-PR36 Roadmap Reconciliation Design

## Goal

Reconcile the official VVIP TIGER phase authority after PR36 without
performing any runtime, production, database, authentication, payment,
migration, RLS, or storage-policy change.

## Approved execution protocol

The owner approved `ARCHITECT-V3` zero-touch execution with:

- atomic OS locking;
- atomic `state.json`;
- watchdog and heartbeat;
- bounded network retry with jitter;
- dry-run before repository mutation;
- checkpoint-friendly idempotent execution;
- no tracked or historical deletion;
- metadata-only quarantine for uncertain paths;
- four independent review gates;
- one documentation commit;
- push and pull-request creation;
- automatic merge disabled.

## Authority model

The official source of truth remains:

- `VVIP_TIGER_MASTER_EXECUTION_ROADMAP.yaml`;
- `phase-status.json`;
- the readable roadmap;
- the phase tracker.

Evidence closes P02 and P03. P04 becomes the next authorized phase
proposal. Foundations merged in PR31 through PR36 are recorded but do
not advance the execution lock beyond P04.

## Safety

Base commit: `{expected_main}`.

Only paths declared in the PR37 manifest may change. Any undeclared
path produces a safe stop. No repository file is quarantined, moved,
deleted, reset, cleaned, or stashed.

## Success criteria

- Dry run passes.
- JSON and YAML parse successfully.
- Machine-readable and human-readable phase values agree.
- P02 and P03 are completed.
- P04 is next authorized.
- Four review reports pass.
- Historical smoke and PR36 tests pass.
- Exact documentation-only scope passes.
- Commit and push succeed.
- A PR is opened without automatic merge.
""",
    encoding="utf-8",
)

plan_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)

plan_path.write_text(
    """# PR37 Post-PR36 Roadmap Reconciliation Implementation Plan

> **For agentic workers:** Execute only through the ARCHITECT-V3
> controller. Do not modify runtime files.

**Goal:** Reconcile repository phase authority and open a reviewable
documentation-only PR.

**Architecture:** Render changes first in an external dry-run tree,
validate them, apply the same deterministic renderer in an isolated
Git worktree, execute four review gates, then commit and push.

**Tech Stack:** Bash, Python 3, Git, GitHub CLI, JSON, YAML.

## Global Constraints

- No direct main changes.
- No SQL, Supabase, Clerk, Service Role, RLS, migration or production
  changes.
- No tracked deletion.
- No reset, clean, stash, rebase or force push.
- No automatic merge.
- P04 remains only a proposal until PR37 is reviewed and merged.

### Task 1: Verify immutable base

- [ ] Verify the clean AFTER-PR36 checkpoint.
- [ ] Fetch origin/main with bounded retries.
- [ ] Require the exact PR36 merge commit.
- [ ] Verify PR29 through PR36 merge evidence.
- [ ] Verify P03 repository evidence.

### Task 2: Execute dry run

- [ ] Copy authority files to the external dry-run tree.
- [ ] Render reconciliation changes.
- [ ] Validate JSON and YAML.
- [ ] Verify documentation-only allowed paths.
- [ ] Confirm no placeholders or forbidden systems.

### Task 3: Apply deterministic reconciliation

- [ ] Create the isolated PR37 worktree and branch.
- [ ] Apply the same renderer.
- [ ] Compare common dry-run outputs with actual outputs.
- [ ] Confirm no runtime path changed.

### Task 4: Four reviews

- [ ] Architecture and source-of-truth consistency.
- [ ] Security, privacy and secret/path controls.
- [ ] Operational resilience, smoke and PR36 regression.
- [ ] Final exact scope and documentation consistency.

### Task 5: Commit and remote review

- [ ] Commit the exact manifest scope.
- [ ] Verify the commit in detached HEAD.
- [ ] Push with bounded network retry and jitter.
- [ ] Open the PR.
- [ ] Do not merge.
""",
    encoding="utf-8",
)

print("RECONCILIATION_RENDER_PASS")
print("PROPOSED_NEXT_PHASE=P04")
print(f"ALLOWED_PATH_COUNT={len(allowed_paths)}")
